from flask import Flask, render_template, request
from flask_mqtt import Mqtt
import ssl

app = Flask(__name__)

app.config['MQTT_BROKER_URL'] = "d47f650ed07746cfa5f7f336869437d9.s1.eu.hivemq.cloud"  # URL for HiveMQ cluster
app.config['MQTT_USERNAME'] = "LewisB"  # From the credentials created in HiveMQ
app.config['MQTT_PASSWORD'] = "Liverpool44"  # From the credentials created in HiveMQ
app.config['MQTT_CLIENT_ID'] = "CourseWork"  # Must be unique for any client that connects to the cluster
app.config['MQTT_BROKER_PORT'] = 8883  # MQTT port for encrypted traffic
app.config['MQTT_KEEPALIVE'] = 60
app.config['MQTT_TLS_ENABLED'] = True
app.config['MQTT_TLS_INSECURE'] = False
app.config['MQTT_TLS_CA_CERTS'] = 'isrgrootx1.pem'  # CA for HiveMQ, read: https://letsencrypt.org/about/
app.config['MQTT_TLS_VERSION'] = ssl.PROTOCOL_TLSv1_2
app.config['MQTT_TLS_CIPHERS'] = None

# Instantiate the mqtt client object (requires instance of flask app as param)
mqtt = Mqtt(app)



@app.route('/')
def publish_test():
    return render_template('index.html')

@app.route('/reset-led')
def reset_led():
    mqtt.publish("led/reset", b"button pressed")
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
